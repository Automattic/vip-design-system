/**
 * External dependencies
 */
import 'jest-axe/extend-expect';
import '@testing-library/jest-dom';
